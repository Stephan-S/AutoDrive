SpecializationUtil.registerSpecialization("LocoDrive", "LocoDrive", g_currentModDirectory.."LocoDrive.lua")

Inching_Register = {};

g_i18n.globalI18N.texts["LocoDrive"] = g_i18n:getText("LocoDrive"); 

local version = SpecializationUtil.getSpecialization("LocoDrive").Version;


function Inching_Register:loadMap(name)
	if self.firstRun == nil then
		self.firstRun = false;
		print("--- loading LocoDrive mod")
		
		for k, v in pairs(g_currentMission.nodeToVehicle) do
			if v ~= nil then
				--print("Vehicle: " .. v.id);
				local loco = v.motorType;
				if loco ~= nil and loco == "locomotive" then
					--print("Found loco. inserting mod");
					table.insert(v.specializations, SpecializationUtil.getSpecialization("LocoDrive"));
				
				end;
			end;
		end;
	end;
end;

function Inching_Register:deleteMap()
  
end;

function Inching_Register:keyEvent(unicode, sym, modifier, isDown)

end;

function Inching_Register:mouseEvent(posX, posY, isDown, isUp, button)

end;

function Inching_Register:update(dt)
	
end;

function Inching_Register:draw()
  
end;

addModEventListener(Inching_Register);