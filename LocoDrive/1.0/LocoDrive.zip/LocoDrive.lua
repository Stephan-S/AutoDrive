





LocoDrive = {};
LocoDrive.Version = "1.0";

function LocoDrive:prerequisitesPresent(specializations)
    return true;
end;

function LocoDrive:delete()	

end;

function LocoDrive:loadMap(name)

end;

function LocoDrive:deleteMap()
end;

function LocoDrive:load(xmlFile)
end;

function LocoDrive:onLeave()

end;

function init(self)
	self.ld = {};
	self.ld.active = true;
	self.ld.register = false;
	self.ld.speed = 35;
	self.ld.firstRun = true;
end;

function LocoDrive:mouseEvent(posX, posY, isDown, isUp, button)

end; 

function LocoDrive:keyEvent(unicode, sym, modifier, isDown) 

end; 

function LocoDrive:update(dt)

	if self == g_currentMission.controlledVehicle then

		if InputBinding.hasEvent(InputBinding.LDEnDisable) then
			--print("handle input");
			if self.ld.active == false then
				if self.cruiseControl ~= nil then
					self.ld.speed = self.cruiseControl.speed;
				end;
				self.ld.active = true;
			else
				self.ld.active = false;
			end;
			LocoDriveInputEvent:sendEvent(self);
		end; 
	end;

	if self.ld == nil then
		init(self);
	end;

	if self.ld.register == false then
		for k, v in pairs(g_currentMission.nodeToVehicle) do
			if v ~= nil then
				--print("Vehicle: " .. v.id);
				local loco = v.motorType;
				if loco ~= nil and loco == "locomotive" then

					exists = false;
					for _,s in pairs(v.specializations) do
						if s == SpecializationUtil.getSpecialization("LocoDrive") then
							exists = true;
						end;
					end;
					if not exists then
						--print("Found loco. inserting mod - update");
						table.insert(v.specializations, SpecializationUtil.getSpecialization("LocoDrive"));
						self.ld.register = true;
						v.ldactive = true;
					end;

				end;
			end;
		end;
	end;

	if self.ld.active == true and g_server ~= nil then
		if self.isMotorStarted == false then
			self:startMotor();
		end;
		if self.setCruiseControlState ~= nil then
			if self.cruiseControl.speed ~= self.ld.speed and self.ld.firstRun == true then
				self:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE);
				self:setCruiseControlMaxSpeed(self.ld.speed);
				self.ld.firstRun = false;
			end;
			if self.cruiseControl.State ~= Drivable.CRUISECONTROL_STATE_ACTIVE then
				self:setCruiseControlState(Drivable.CRUISECONTROL_STATE_ACTIVE);
			end;
			if not self.isEntered and g_dedicatedServerInfo == nil then
				Drivable.updateVehiclePhysics(self, self.axisForward, self.axisForwardIsAnalog, self.axisSide, self.axisSideIsAnalog, self.doHandbrake, dt);
			end;
		end;

	else
		if self.setCruiseControlState ~= nil and self.cruiseControl.state == Drivable.CRUISECONTROL_STATE_ACTIVE then
			self:setCruiseControlState(Drivable.CRUISECONTROL_STATE_OFF);
		end;
	end;


end;

function LocoDrive:draw()

end; 

addModEventListener(LocoDrive);


--InputEvent%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--InputEvent%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
--InputEvent%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


LocoDriveInputEvent = {};
LocoDriveInputEvent_mt = Class(LocoDriveInputEvent, Event);

InitEventClass(LocoDriveInputEvent, "LocoDriveInputEvent");

function LocoDriveInputEvent:emptyNew()
	local self = Event:new(LocoDriveInputEvent_mt);
	self.className="LocoDriveInputEvent";
	return self;
end;

function LocoDriveInputEvent:new(vehicle)
	local self = LocoDriveInputEvent:emptyNew()
	self.vehicle = vehicle;

	self.bLDActive = vehicle.ld.active;
	self.nLDSpeed = vehicle.ld.speed;
	--print("event new")
	return self;
end;

function LocoDriveInputEvent:writeStream(streamId, connection)
	streamWriteInt32(streamId, networkGetObjectId(self.vehicle));

	streamWriteBool(streamId, self.bLDActive);
	streamWriteInt32(streamId, self.nLDSpeed);
	-- print("event writeStream")
end;

function LocoDriveInputEvent:readStream(streamId, connection)
	--print("Received Event");

	local id = streamReadInt32(streamId);
	local vehicle = networkGetObject(id);

	local bLDActive = streamReadBool(streamId);
	local nLDSpeed = streamReadInt32(streamId);
	--print("Event Received. speed set to: " .. nLDSpeed);

	if vehicle.ld ~= nil then
		vehicle.ld.active = bLDActive;
		vehicle.ld.speed = nLDSpeed;
	end;

	if g_server ~= nil then
		g_server:broadcastEvent(LocoDriveInputEvent:new(vehicle), nil, nil, vehicle);
		-- print("broadcasting")
	end;
end;

function LocoDriveInputEvent:sendEvent(vehicle)
	if g_server ~= nil then
		g_server:broadcastEvent(LocoDriveInputEvent:new(vehicle), nil, nil, vehicle);
		-- print("broadcasting")
	else
		g_client:getServerConnection():sendEvent(LocoDriveInputEvent:new(vehicle));
		-- print("sending event to server...")
	end;
end;