Getting started:
    1. Copy FS17_GlobalMarket.zip and FS17_GlobalStorage into your FarmingSimulator17/mods folder
    2. Download the client application here: https://github.com/Stephan-S/AutoDrive/raw/master/GlobalMarket/globalMarket.zip
	Exract it and copy the folder globalMarket directly into you FarmingSimulator17 folder
        Required Folder Structure:
            FarmingSimulator17/mods/FS17_GlobalMarket.zip
            FarmingSimulator17/mods/FS17_GlobalStorage.zip
            FarmingSimulator17/globalMarket
    3. Have a look at the config file located at
        FarmingSimulator17/globalMarket/economy_data.xml
            3.1: In there, you can already edit your username from but that is not required
            3.2: You can select which hub you want to connect to
                 "global" is the standard hub which should be available to everyone
                 If you want to create or connect to a personal hub, write "your_hub_name" instead of global. Where "your_hub_name" is the name of the new hub
            3.3: In useMoney, you can select if you wish to receive/pay money for trading. If you write a 0 in there. You wont have to pay for anything in the storage, but this wont work in the "global" hub
            3.4: Under servername you can leave the default value to connect to my dedicated server where the "global" storage is located, but also all other hubs defined by users
                 If you wish to host your own server locally write "127.0.0.1" and start the server.exe in the FarmingSimulator17/globalMarket folder
     4. Start the client.exe located in FarmingSimulator17/globalMarket
     5. Start your game and dont forget to select both mods when starting
     6. Place ONE "Global Storage" building anywhere on your map, save the game and restart it
     7. From now on, whenver you start up your game, the client will synchronize the storage of the "Global Storage" building with the selected hub on the selected server
     
Anleitung:
    1. FS17_GlobalMarket.zip und FS17_GlobalStorage in deinen LandwirtshcaftsSimulator17/mods Ordner kopieren
    2. Den Ordner "globalMarket"  in deinen LandwirtshcaftsSimulator17 Ordner kopieren. Achtung! Nicht in den mods Ordner sondern eine Ebene dar�ber also in der Form:
                LandwirtshcaftsSimulator17/globalMarket
    3. Schau in die config Datei globalMarket/economy_data.xml rein
        3.1: Den Nutzernamen kann man optional eintragen unter <username>
        3.2: Du kannst w�hlen zu welchen "hub" du dich verbinden m�chtest.
             "global" ist der Standard Hub auf den jeder Zugriff haben sollte
             "dein_hub_name" kannst du dort auch eintragen, falls du einen privaten hub haben m�chtest
        3.3: Falls du kein Geld f�r die Waren bezahlen/erhalten m�chtest, setze eine 0 anstelle der 1 in <useMoney>. Beim "global" hub wird dies allerdings nicht beachtet und wird immer als 1 gewertet
        3.4: Falls du einen eigenen Server hast und nicht auf meinen Standard Server verbinden m�chtest, trag unter <servername> die IP ein. Lokal w�re �brigens "127.0.0.1"
             Um einen lokalen Server zu starten starten, f�hre die server.exe im globalMarket Ordner aus
    4. Starte die client.exe im globalMarket Ordner. Der client muss immer laufen wenn du verbunden sein m�chtest.
    5. Spiel starten und nicht vergessen beide Mods auszuw�hlen
    6. Einmal unter platzierbaren Geb�uden das "Global Storage" aufstellen. Spiel speichern und neustarten
    7. Ab jetzt sollte der Inhalt vom "Global Storage" geb�ude mit dem gew�hlten hub auf dem gew�hlten Server synchronisisert sein

