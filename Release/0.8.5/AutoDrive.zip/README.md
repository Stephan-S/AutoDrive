# AutoDrive
This is a script for the Farming Simulator 17 which lets your tractor drive to destinations autonomously
